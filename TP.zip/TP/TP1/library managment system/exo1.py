nums = (10, 20, 30)
print(nums[1])
print(len(nums))
print(sum(nums))